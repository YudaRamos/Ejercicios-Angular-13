import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  alumnos: any[] = [
    {valoracion: 'alta', repetidor: false, nombre: 'Juan', apelido: 'Lopez', nota:7.5},
    {valoracion: 'baja',repetidor: true, nombre: 'Elena', apelido: 'Ramos', nota:2.1},
    {valoracion: 'alta',repetidor: false, nombre: 'Raul', apelido: 'Diaz', nota:9.0},
    {valoracion: 'baja',repetidor: true, nombre: 'Carlos', apelido: 'Carral', nota:3.8},
    {valoracion: 'alta',repetidor: false, nombre: 'Marga', apelido: 'González', nota:8.5},
    {valoracion: 'media',repetidor: true, nombre: 'Felix', apelido: 'Gomez', nota:6.5},
    {valoracion: '',repetidor: true, nombre: 'Miguel', apelido: 'Perez', nota:6.0}

  ];
}
