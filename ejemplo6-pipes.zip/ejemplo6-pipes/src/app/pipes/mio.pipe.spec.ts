import { MioPipe } from './mio.pipe';

describe('MioPipe', () => {
  it('create an instance', () => {
    const pipe = new MioPipe();
    expect(pipe).toBeTruthy();
  });
});
