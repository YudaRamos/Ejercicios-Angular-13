import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  nombres: any = [
    {nombre: 'Juan', color: 'yellow'},
    {nombre: 'Maria', color: 'orange'},
    {nombre: 'Pedro', color: 'pink'},
    {nombre: 'Laura', color: 'blue'},
    {nombre: 'Jorge', color: 'green'},
    {nombre: 'Lucia', color: 'red'}
  ];
 
}