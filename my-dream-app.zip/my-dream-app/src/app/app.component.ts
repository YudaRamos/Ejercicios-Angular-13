import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  nombre: string = 'Yudaisy';
  apellidos: string = "Ramos Díaz";
  dashabilitado: boolean = true;
  texto: string = '';

  constructor(){
    //crear un temporizador que cdo trascurran 3 seg se habilite el botón
    setTimeout(()=>{
      this.dashabilitado = false;
    }, 3000);
  }

  saludar(): void{
    alert("Bienvenidos al curso de Angular");
  }
}
