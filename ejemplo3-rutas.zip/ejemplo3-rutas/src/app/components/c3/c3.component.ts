import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-c3',
  templateUrl: './c3.component.html',
  styleUrls: ['./c3.component.css']
})
export class C3Component implements OnInit {
  hotel: string = '';
  entrada: string= '';
  salida: string= '';
  habitaciones: number = 0;

  constructor(private ruta: ActivatedRoute) {
    console.log(ruta.snapshot);
    //recuperar el parámetro de la ruta
    // con el mismo nombre que se ha declarado en el appendFile.module.ts
    this.hotel = ruta.snapshot.params['hotel'];

    //recuperar [queryParams] con el mismo nombre qu elo hemos enviado
    this.entrada = ruta.snapshot.queryParams['entrada'];
    this.salida = ruta.snapshot.queryParams['salida'];
    this.habitaciones = ruta.snapshot.queryParams['habitaciones'];

   }

  ngOnInit(): void {
  }

}
